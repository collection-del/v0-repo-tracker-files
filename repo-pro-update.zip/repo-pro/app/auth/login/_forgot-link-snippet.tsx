// ─────────────────────────────────────────────────────────
// PATCH: Add this link below the password field in your
//        existing  app/auth/login/page.tsx
//
// Find the line where your password <input> ends and add:
// ─────────────────────────────────────────────────────────

import Link from "next/link"

// Inside your login form JSX, after the password input:
export function ForgotPasswordLink() {
  return (
    <div className="flex justify-end mt-1">
      <Link
        href="/auth/forgot-password"
        className="text-[10px] font-semibold text-[#7788aa] hover:text-[#c2ff00] transition-colors tracking-wide"
      >
        ¿Olvidaste tu contraseña?
      </Link>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// If you prefer, just paste the raw JSX directly:
// ─────────────────────────────────────────────────────────
//
//  <div className="flex justify-end mt-1">
//    <Link
//      href="/auth/forgot-password"
//      className="text-[10px] font-semibold text-[#7788aa] hover:text-[#c2ff00] transition-colors tracking-wide"
//    >
//      ¿Olvidaste tu contraseña?
//    </Link>
//  </div>
