"use client"

// ─────────────────────────────────────────────────────────
// HOW TO USE REALTIME IN YOUR COMPONENT
//
// Copy the relevant parts into your AppShell or whichever
// client component manages repos / inventory state.
// ─────────────────────────────────────────────────────────

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { useRealtimeAll } from "@/hooks/use-realtime"
import { isAdmin } from "@/lib/utils"
import type { User } from "@supabase/supabase-js"
import type { Repo, InventoryItem } from "@/lib/types"

// ── 1. Initial data fetch (runs once on mount) ────────────
async function fetchAll() {
  const supabase = createClient()

  const [{ data: repos }, { data: inventory }] = await Promise.all([
    supabase
      .from("repos")
      .select("*")
      .order("created_at", { ascending: false }),
    supabase
      .from("inventory")
      .select("*")
      .order("created_at", { ascending: false }),
  ])

  return {
    repos: (repos ?? []) as Repo[],
    inventory: (inventory ?? []) as InventoryItem[],
  }
}

// ── 2. Component example ──────────────────────────────────
export function AppShellWithRealtime({ user }: { user: User }) {
  const [repos, setRepos] = useState<Repo[]>([])
  const [inventory, setInventory] = useState<InventoryItem[]>([])
  const [loading, setLoading] = useState(true)

  // Initial load
  useEffect(() => {
    fetchAll().then(({ repos, inventory }) => {
      setRepos(repos)
      setInventory(inventory)
      setLoading(false)
    })
  }, [])

  // ── Realtime: keeps every open tab/device in sync ──────
  useRealtimeAll({
    onRepo: ({ eventType, new: n, old: o }) => {
      setRepos((prev) => {
        if (eventType === "INSERT" && n) return [n, ...prev]
        if (eventType === "DELETE" && o?.id) return prev.filter((r) => r.id !== o.id)
        if (eventType === "UPDATE" && n) return prev.map((r) => (r.id === n.id ? n : r))
        return prev
      })
    },
    onInventory: ({ eventType, new: n, old: o }) => {
      setInventory((prev) => {
        if (eventType === "INSERT" && n) return [n, ...prev]
        if (eventType === "DELETE" && o?.id) return prev.filter((i) => i.id !== o.id)
        if (eventType === "UPDATE" && n) return prev.map((i) => (i.id === n.id ? n : i))
        return prev
      })
    },
  })

  // ── Admin check: Bono only visible to collection@amigocash.com ──
  const admin = isAdmin(user.email)

  if (loading) return <div>Cargando…</div>

  return (
    <div>
      {/* Your existing UI here */}

      {/* Bono column / section — only renders for admin */}
      {admin && (
        <div className="bono-section">
          {/* Bono calculations, table column, etc. */}
        </div>
      )}
    </div>
  )
}
